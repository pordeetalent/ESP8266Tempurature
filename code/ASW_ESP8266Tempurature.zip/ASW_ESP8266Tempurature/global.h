#ifndef __GLOBAL_H
#define __GLOBAL_H

#define WLAN_SSID "xxxxx"       
#define WLAN_PASS "xxxxx"

#endif
