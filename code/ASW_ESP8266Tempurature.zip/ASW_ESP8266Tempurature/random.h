#ifndef __RANDOM_H
#define __RANDOM_H

extern char ClientID[24];

extern void set_wifi(void);
extern char generateClientID (void); 

#endif
