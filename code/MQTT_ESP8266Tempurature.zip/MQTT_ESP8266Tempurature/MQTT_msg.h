#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include "global.h"

const char* ssid = WLAN_SSID; // Enter your WiFi name
const char* password =  WLAN_PASS; // Enter WiFi password
const char* mqttServer = "202.139.197.40";
const int mqttPort = 1883;
const char* mqttUser = "hapybot";
const char* mqttPassword = "Depa@1234";
 
WiFiClient espClient;
PubSubClient client(espClient);

void callback(char* topic, byte* payload, unsigned int length) {
 
  Serial.print("Message arrived in topic: ");
  Serial.println(topic);
 
  Serial.print("Message:");
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]);
  }
 
  Serial.println();
  Serial.println("-----------------------");
}

void setMqtt(){
  while (!Serial) ;
  WiFi.begin(ssid, password);
 
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }
  Serial.println("Connected to the WiFi network");
 
  client.setServer(mqttServer, mqttPort);
  client.setCallback(callback);
 
  while (!client.connected()) {
    Serial.println("Connecting to MQTT...");
 
    if (client.connect("temi4", mqttUser, mqttPassword )) {
 
      Serial.println("connected");  
 
    } else {
 
      Serial.print("failed with state ");
      Serial.print(client.state());
      delay(2000);
    }
  }
  client.publish("temi4", "start"); //Topic name
  client.subscribe("esp/test");
}
void mqtt_msg(String Text){
  client.publish("temi4", (Text).c_str(), true);
  //client.publish("temi4", ("Ambient: " + String(mlx.readAmbientTempC()) + " C").c_str(), true);
}

